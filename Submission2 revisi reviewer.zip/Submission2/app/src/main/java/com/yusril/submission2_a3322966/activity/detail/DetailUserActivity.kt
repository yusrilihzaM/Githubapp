package com.yusril.submission2_a3322966.activity.detail

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.tabs.TabLayoutMediator
import com.yusril.submission2_a3322966.R
import com.yusril.submission2_a3322966.databinding.ActivityDetailUserBinding
import com.yusril.submission2_a3322966.model.User
import com.yusril.submission2_a3322966.viewModel.UserDetailMainModel

class DetailUserActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_USER = "extra_user"
        @StringRes
        private  val TAB_TITLES= intArrayOf(
            R.string.follower,
            R.string.following
        )
    }
    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var userDetailMainModel: UserDetailMainModel
    private var shareData:String?=null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_user)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userDetailMainModel= ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            UserDetailMainModel::class.java
        )

        val user=intent.getParcelableExtra<User>(EXTRA_USER) as User
        Log.d(this@DetailUserActivity.toString(),user.toString())
        userDetailMainModel.setUserDetail(user.username)
        supportActionBar?.title="@"+user.username
        shareData=user.username

        //bg detail// revisi dari reviewer
        Glide.with(this)
                .load(R.drawable.bg_detail)
                .into(binding.imgBgDetail)

        Glide.with(this)
            .load(user.avatar)
            .apply(RequestOptions().override(155, 155))
            .into(binding.imgPhoto)

        userDetailMainModel.getUserDetail().observe(this, { useritem ->
            if (useritem != null) {
                val data = useritem[0]
                var name=data.name
                var follower=data.follower
                var following=data.following
                var location=data.location
                var company=data.company
                //jika data kosong maka ganti -
                if(name=="null"){
                    name="-"
                }
                if(follower=="null"){
                    follower="-"
                }
                if(following=="null"){
                    following="-"
                }
                if(location=="null"){
                    location="-"
                }
                if(company=="null"){
                    company="-"
                }
                binding.tvName.text = name
                binding.tvFollower.text = follower
                binding.tvFollowing.text = following
                binding.tvLocation.text = location
                binding.tvCompany.text = company
            }
        })

        // viewpager
        val sectionsPagerAdapter=SectionsPagerAdapter(this)
        sectionsPagerAdapter.username=user.username// kirim data ke Viewpager setter// sesuai video intruksi dicoding
        val viewPager=binding.viewPager
        viewPager.adapter=sectionsPagerAdapter//set adapter view pager

        // tablayout
        val tabs=binding.tabs
        // masukan tab dan viewpager
        TabLayoutMediator(tabs, viewPager){ tab, position->
            tab.text=resources.getString(TAB_TITLES[position])
        }.attach()//sisipkan


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val intent= Intent()
        intent.action= Intent.ACTION_SEND
        intent.putExtra(Intent.EXTRA_TEXT, shareData)
        intent.type="text/plain"
        startActivity(Intent.createChooser(intent, R.string.share.toString()))
        return super.onOptionsItemSelected(item)
    }

}